package com.koravel.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/admin")
public class AdminController {

	
	@RequestMapping("test.do")
	public void admin() {
		System.out.println("===> admin() 실");
	}
}
