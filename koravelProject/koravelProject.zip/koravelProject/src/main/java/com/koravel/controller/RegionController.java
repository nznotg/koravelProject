package com.koravel.controller;



import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.koravel.domain.RegionReviewVO;
import com.koravel.domain.RegionVO;
import com.koravel.service.RegionReviewService;
import com.koravel.service.RegionService;

@Controller
@RequestMapping("/region")
public class RegionController {

	@Autowired
	private RegionService regionService;
	
	@Autowired
	private RegionReviewService regionreviewService;
	
	@RequestMapping("{step}.do")
	public String test(@PathVariable String step) {
		return "/region/" + step;
	}
	
	// 맞춤 추천 페이지
	@RequestMapping("recommand.do")
	public void recommandPage(RegionVO vo, Model m) {
		System.out.println("===> recommandPage 실행");
		List<HashMap> regionList = regionService.getRegionList(vo);
		List<HashMap> keywordList = regionService.getKeywordList();
		m.addAttribute("regionList", regionList);
		m.addAttribute("keywordList", keywordList);
		
		for(HashMap check1 : regionList) {
			System.out.println(check1);
		}
		
		for(HashMap check2 : keywordList) {
			System.out.println(check2);
		}
	}
	
//	@RequestMapping("recommand.do")
//	public void test(RegionVO vo, Model m) {
//		System.out.println("===> testList 실행");
//		RegionVO result = regionService.getRegion(vo);
//		m.addAttribute("region", result);
//	}
	
//	@RequestMapping("recommand.do")
//	public String test(RegionVO vo, Model m){
//		System.out.println("===> test() 실행");
//		HashMap<String, Object> hashMap = new HashMap<>();
//		List<RegionVO> list = regionService.getRegionList(vo);
//		for(RegionVO check:list) {
//			System.out.println(check);
//		}
//		
//		hashMap.put("hashMapList", list);
//		m.addAttribute("hashMapList", list);
//		return "/region/recommand";
//	}
	
	
	// 여행지 상세보기 페이지
	@RequestMapping("detailRegion.do")
	public void detailBoard(RegionVO vo, Model m, RegionReviewVO rvo) {
		RegionVO result = regionService.getRegion(vo);
		List<HashMap> reviewresult = regionreviewService.review(rvo);
			// HashMap에 잘 담겼는지 확인
			for(HashMap review : reviewresult) {
				System.out.println(review);
			}
		m.addAttribute("region", result);
		m.addAttribute("regionReview", reviewresult);
	}
}
