package com.koravel.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.koravel.domain.KoravelVO;
import com.koravel.service.KoravelService;


@Controller
@RequestMapping("/user")
public class koravelController {
	
	@Autowired
	private KoravelService krService;
	
	
	@RequestMapping("{step}.do")
	public String userJoin(@PathVariable String step) {
		System.out.println(step);
		return "/user/"+step;
	}
	
	@RequestMapping(value="userInsert.do", method=RequestMethod.POST)
	public ModelAndView userInsert(KoravelVO vo) {
		System.out.println("===> Controller userInsert 실행");
		System.out.println(vo.getUsrID());
		int result = krService.userInsert(vo);
		String message = null;
		if(result == 1) message = "Join Success!" + vo.getUsrNick() + "님 반값습니다.";
		else message = "Join Fail. Return JoinHome";
		
		ModelAndView mv = new ModelAndView();
		mv.setViewName("/user/userJoin_ok");
		mv.addObject("message", message);
		
		return mv;
	}
	
	@RequestMapping(value="idCheck.do", produces="application/text; charset=utf-8")
	@ResponseBody
	public String idCheck(KoravelVO vo) {
		System.out.println("===> Controller idCheck 실행");
		KoravelVO result = krService.idCheck_login(vo);
		String message = "Can use";
		if(result != null) message = "Can't use, try diffrent typing";
		
		return message;
	}
}