package com.koravel.dao;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.koravel.domain.KoravelVO;

@Repository
public class KoravelDAOImpl implements KoravelDAO {
	

	@Autowired
	public SqlSessionTemplate mybatis;
	
	@Override
	public KoravelVO idCheck_login(KoravelVO vo) {
		System.out.println("===> krDAO.idCheck_login 실행");
		return mybatis.selectOne("user.idCheck", vo);
	}

	@Override
	public int userInsert(KoravelVO vo) {
		System.out.println("===> krDAO.userInsert 실행");
		return mybatis.insert("user.userInsert", vo);
	}
	

}
