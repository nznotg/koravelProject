package com.koravel.dao;

import java.util.HashMap;
import java.util.List;

import com.koravel.domain.RegionVO;


public interface RegionDAO {
	
	// 특정 지역 정보만 가져오
	public RegionVO getRegion(RegionVO vo);
	
	// 맞춤 페이지 : 지역 정보 리스트 가져오
	public List<HashMap> getRegionList(RegionVO vo);
	
	// 키워드 가져오
	public List<HashMap> getKeywordList();

}
