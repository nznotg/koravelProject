package com.koravel.dao;

import java.util.HashMap;
import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.koravel.domain.RegionVO;

@Repository
public class RegionDAOImpl implements RegionDAO {

	@Autowired
	public SqlSessionTemplate mybatis;
	
	
	@Override
	public RegionVO getRegion(RegionVO vo) {
		System.out.println("===> regionDAO.getRegion 실행");
		return mybatis.selectOne("region.getRegion", vo);
	}
	
	@Override
	public List<HashMap> getRegionList(RegionVO vo) {
		System.out.println("===> regionDAO.getRegionList 실행");
		return mybatis.selectList("region.getRegionList");
	}
	
	@Override
	public List<HashMap> getKeywordList(){
		System.out.println("===> regionDAO.getKeywordList 실행");
		return mybatis.selectList("region.getKeywordList");
	}

}
