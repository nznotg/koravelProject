package com.koravel.dao;

import java.util.HashMap;
import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.koravel.domain.RegionReviewVO;

@Repository 
public class RegionReviewDAOImpl implements RegionReviewDAO{
	
	@Autowired
	private SqlSessionTemplate mybatis;

	@Override
	public List<HashMap> review(RegionReviewVO rvo) {
		System.out.println("===> Mybatis review() 호출");
		return mybatis.selectList("region.review", rvo);
	}
}