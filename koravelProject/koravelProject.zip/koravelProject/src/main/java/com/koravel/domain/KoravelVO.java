package com.koravel.domain;

import java.sql.Date;

import lombok.Data;

@Data
public class KoravelVO {
   private int usrIdx;
   private String usrID;
   private String usrPasswd;
   private String usrEmail;
   private String usrBirth;
   private String usrNick;
   private Date usrSince;
   private Date usrSubscribe;
   private int usrPoint;
   
}
