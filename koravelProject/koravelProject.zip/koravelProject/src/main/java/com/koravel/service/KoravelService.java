package com.koravel.service;

import com.koravel.domain.KoravelVO;

public interface KoravelService {
	
	public KoravelVO idCheck_login(KoravelVO vo);
	public int userInsert(KoravelVO vo);
}
