package com.koravel.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.koravel.dao.KoravelDAO;
import com.koravel.domain.KoravelVO;

@Service
public class KoravelServiceImpl implements KoravelService{

	@Autowired
	public KoravelDAO krDAO;
	
	@Override
	public KoravelVO idCheck_login(KoravelVO vo) {
		return krDAO.idCheck_login(vo);

	}

	@Override
	public int userInsert(KoravelVO vo) {
		return krDAO.userInsert(vo);
	}

}
