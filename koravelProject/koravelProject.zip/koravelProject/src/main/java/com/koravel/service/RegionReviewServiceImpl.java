package com.koravel.service;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.koravel.dao.RegionReviewDAO;
import com.koravel.dao.RegionReviewDAOImpl;
import com.koravel.domain.RegionReviewVO;

@Service
public class RegionReviewServiceImpl implements RegionReviewService {
	
	@Autowired
	private RegionReviewDAOImpl regionReviewDAO;

	@Override
	public List<HashMap> review(RegionReviewVO rvo) {
		return regionReviewDAO.review(rvo);
	}
}