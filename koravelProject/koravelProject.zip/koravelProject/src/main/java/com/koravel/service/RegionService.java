package com.koravel.service;

import java.util.HashMap;
import java.util.List;

import com.koravel.domain.RegionVO;

public interface RegionService {
	
	public List<HashMap> getRegionList(RegionVO vo);

	public RegionVO getRegion(RegionVO vo);

	public List<HashMap> getKeywordList();


}
