$(function(){
	// 사용자의 자료 입력여부를 검사하는 함수
	$('#confirm').click(function(){
    	if( $.trim($("#usrID").val()) == '' ){
            alert("아이디를 입력해 주세요.");
            $("#usrID").focus();
            return;
        }
    	
    	if($.trim($('#passwd').val())==''){
    		alert("비번입력해주세요.");
    		$('#passwd').focus();
    		return;
    	}
    	
    	if($.trim($('#passwd').val()) != $.trim($('#passwd2').val())){
    		alert("비밀번호가 일치하지 않습니다..");
    		$('#passwd2').focus();
    		return;
    	}
    	
    	if($.trim($('#usrNick').val())==''){
    		alert("이름입력해주세요.");
    		$('#usrNick').foucs();
    		return;
    	}
    	
    	if($.trim($('#usrEmail').val())==''){
    		alert("이메일을 입력해주세요.");
    		$('#usrEmail').foucs();
    		return;
    	}
    	
    	if($.trim($('#usrBirth').val())==''){
    		alert("닉네임을 입력해주세요.");
    		$('#usrBirth').foucs();
    		return;
    	}
       
        // 자료를 전송합니다.
        document.userinput.submit();
	});
	
	/* //아이디 중복체크
	$('#usrID').keyup(function(){
        
       
	}) */
})
