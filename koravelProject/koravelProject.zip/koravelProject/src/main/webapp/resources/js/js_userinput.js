$(function(){

	document.getElementById('usrSince').value= new Date().toISOString().slice(0,10); // ==> usrSince : yyyy-mm-dd 패턴으로 오늘 날짜 디폴트
	document.getElementById('usrSubscribe').value= new Date().toISOString().slice(0,10); // ==> usrSince : yyyy-mm-dd 패턴으로 오늘 날짜 디폴트

	// 사용자의 자료 입력여부를 검사하는 함수
	$("#confirm").click(function(){
	
		console.log("click event");
    	if($.trim($("#usrID").val()) == '' ){  //$.trim('selector') = 좌우 공백 제거
            alert("아이디를 입력해 주세요.");
            $("#usrID").focus();
            return;
        }
    	
    	if($.trim($('#usrPasswd').val()) == ''){
    		alert("비번입력해주세요.");
    		$('#usrPasswd').focus();
    		return;
    	}
    	
    	if($.trim($('#usrPasswd').val()) != $.trim($('#usrPasswd2').val() )){
    		alert("비밀번호가 일치하지 않습니다.");
    		$('#usrPasswd2').focus();
    		return;
    	}
    	
    	if($.trim($('#usrNick').val()) == ''){
    		alert("이름입력해주세요.");
    		$('#usrNick').focus();
    		return;
    	}
    	
    	if($.trim($('#usrEmail').val()) == ''){
    		alert("이메일을 입력해주세요.");
    		$('#usrEmail').focus();
    		return;
    	}
    	
    	if($.trim($('#usrBirth').val()) == ''){
    		alert("생년월일 입력해주세요.");
    		$('#usrBirth').focus();
    		return;
    	}
    	if($.trim($('#usrSince').val()) == ''){
    		alert("가입일을 입력해주세요.");
    		$('#usrSince').focus();
    		return;
    	}
    	if($.trim($('#usrSubscribe').val()) == ''){
    		alert("구독을 입력해주세요.");
    		$('#usrSubscribe').focus();
    		return;
    	}
   		
   		
   		document.userInsert.submit();
	});

		//아이디 중복체크
	$('#idCheck').click(function(){
        $.ajax({
        	type:'get',
        	url:'idCheck.do',
        	data: {usrID:$('#usrID').val()},
        	//한글처리 필요(아래)
        	contentType: 'application/x-www-form-urlencoded; charset=UTF-8',
        	success: idChek_ok,
        	error: function(err) {
        		alert('서버로부터 데이터를 받지 못했습니다.');        	
        	}
        });
        
        function idChek_ok(result){
        	$('#idCheckResult').text(result);
        }
       
	});

})
	
	
	
	
	
	
	
	